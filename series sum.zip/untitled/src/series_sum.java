public class series_sum
{
    int s=0,p=1;
    int sum(int n)
    {
        for(int i=1;i<=n;i++)
            s+=i;
        return s;
    }

    int product(int o)
    {
        for(int i=1;i<=o;i++)
            p*=i;
        return p;
    }

    static void main(int in)
    {
        series_sum ob=new series_sum();
        double s=0;
        for(int i=1;i<=in;i++)
            s=s+((double)ob.sum(i)/ob.product(i));
        System.out.println(s);
    }
}