public class Main {
    public static void main(String[] args) {

        series_sum ob= new series_sum();
        ob.main(5);
    }
}